#ch6_example.py

def first(chars):
    chars.sort()
    return chars[0]

def last(chars):
    chars.sort()
    return chars[-1]
